var searchData=
[
  ['plazas_5flibres_41',['plazas_libres',['../class_cjt__estaciones.html#ab954d2380bf4a840ace62f6bdd9543dd',1,'Cjt_estaciones']]],
  ['plazas_5ftotales_42',['plazas_totales',['../class_cjt__estaciones.html#a235ef57ddf7b4cb62b22e3c97952e991',1,'Cjt_estaciones']]],
  ['plazas_5fusadas_43',['plazas_usadas',['../class_cjt__estaciones.html#a2558cf6cf649e8afe48a9d7508391bd4',1,'Cjt_estaciones']]],
  ['poca_5fcapacidad_44',['poca_capacidad',['../class_cjt__estaciones.html#af8311ad268055f12b8e8bff9ecc82c33',1,'Cjt_estaciones']]],
  ['program_2ecc_45',['program.cc',['../program_8cc.html',1,'']]]
];
