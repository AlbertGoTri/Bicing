var searchData=
[
  ['plazas_5flibres_91',['plazas_libres',['../class_cjt__estaciones.html#ab954d2380bf4a840ace62f6bdd9543dd',1,'Cjt_estaciones']]],
  ['poca_5fcapacidad_92',['poca_capacidad',['../class_cjt__estaciones.html#af8311ad268055f12b8e8bff9ecc82c33',1,'Cjt_estaciones']]]
];
